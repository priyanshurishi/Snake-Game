# Snake-Game
An interactive Java Application where the user can play a game of Snake.

<img src="https://user-images.githubusercontent.com/96363633/148671725-20b81ad1-6dea-4e34-b03a-2a962ed3bab6.png" data-canonical-src="https://user-images.githubusercontent.com/96363633/148671725-20b81ad1-6dea-4e34-b03a-2a962ed3bab6.png" width="395" height="466" />


This Java app provides a set of instructions for the user, allows the user to control the movement of the snake, updates the score and ends the game depending on certain conditions. This was made for my final Grade 12 computer science project.
